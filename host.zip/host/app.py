import flask
import pickle
import pandas as pd

# Use pickle to load in the pre-trained model.
with open(f'model/model.pkl', 'rb') as f:
    model = pickle.load(f)
    print(model.feature_names_in_())
    
app = flask.Flask(__name__, template_folder='templates')

@app.route('/', methods=['GET', 'POST'])
def main():
    if flask.request.method == 'GET':
        return(flask.render_template('main.html'))
    
    if flask.request.method == 'POST':        
        #belongs_to_collection = flask.request.form['belongs_to_collection']
        #budget = flask.request.form['budget']
        #genres = flask.request.form['genres']
        #homepage = flask.request.form['homepage']
        #original_language = flask.request.form['original_language']
        #popularity = flask.request.form['popularity']
        #production_companies = flask.request.form['production_companies']
        #production_countries = flask.request.form['production_countries']
        #release_date = flask.request.form['release_date']
        #runtime = flask.request.form['runtime']
        #spoken_languages = flask.request.form['spoken_languages']
        #keywords = flask.request.form['keywords']
        #cast = flask.request.form['cast']
        #crew = flask.request.form['crew']
        #revenue = flask.request.form['revenue']
        
        input_variables = pd.DataFrame([[
        belongs_to_collection,
        budget,
        genres,
        homepage,
        original_language,
        popularity,
        production_companies,
        production_countries,
        release_date,
        runtime,
        spoken_languages,
        keywords,
        cast,
        crew,
        revenue]],

        columns=[
        'belongs_to_collection',
        'budget',
        'genres',
        'homepage',
        'original_language',
        'popularity',
        'production_companies',
        'production_countries',
        'release_date',
        'runtime',
        'spoken_languages',
        'keywords',
        'cast',
        'crew',
        'revenue'
        ],
        
        dtype=float)        
        
        prediction = model.predict(input_variables)[0]  

        return flask.render_template('main.html',

        original_input={        
        'belongs_to_collection':belongs_to_collection,
        'budget':budget,
        'genres':genres,
        'homepage':homepage,
        'original_language':original_language,
        'popularity':popularity,
        'production_companies':production_companies,
        'production_countries':production_countries,
        'release_date':release_date,
        'runtime':runtime,
        'spoken_languages':spoken_languages,
        'keywords':keywords,
        'cast':cast,
        'crew':crew,
        'revenue':revenue},result=prediction,)
    
    
